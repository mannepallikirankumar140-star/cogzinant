package com.cognizant.ormlearn;

public class OrmLearnApplication {
}
