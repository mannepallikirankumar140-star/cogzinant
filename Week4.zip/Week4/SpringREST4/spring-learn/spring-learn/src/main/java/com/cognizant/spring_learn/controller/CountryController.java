package com.cognizant.spring_learn.controller;

import com.cognizant.spring_learn.model.Country;
import com.cognizant.spring_learn.service.CountryService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/countries")
public class CountryController {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(CountryController.class);

    private final CountryService countryService;

    public CountryController(CountryService countryService) {
        this.countryService = countryService;
    }

    @GetMapping
    public List<Country> getAllCountries() {
        LOGGER.info("Start - getAllCountries");
        return countryService.getAllCountries();
    }

    @GetMapping("/{code}")
    public ResponseEntity<Country> getCountry(@PathVariable String code) {
        Country country = countryService.getCountry(code);

        if (country == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(country);
    }

    @PostMapping
    public ResponseEntity<Country> addCountry(@RequestBody @Valid Country country) {
        LOGGER.info("Start - addCountry: {}", country);

        Country savedCountry = countryService.addCountry(country);

        return ResponseEntity.status(HttpStatus.CREATED).body(savedCountry);
    }

    @PutMapping
    public ResponseEntity<Country> updateCountry(@RequestBody @Valid Country country) {
        Country updatedCountry = countryService.updateCountry(country);

        if (updatedCountry == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(updatedCountry);
    }

    @DeleteMapping("/{code}")
    public ResponseEntity<Void> deleteCountry(@PathVariable String code) {
        boolean deleted = countryService.deleteCountry(code);

        if (!deleted) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.noContent().build();
    }
}