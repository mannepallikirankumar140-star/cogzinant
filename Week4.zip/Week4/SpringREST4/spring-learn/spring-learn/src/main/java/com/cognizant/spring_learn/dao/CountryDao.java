package com.cognizant.spring_learn.dao;

import com.cognizant.spring_learn.model.Country;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CountryDao {

    private final List<Country> countries = new ArrayList<>();

    public CountryDao() {
        countries.add(new Country("IN", "India"));
        countries.add(new Country("US", "United States"));
    }

    public List<Country> getAllCountries() {
        return countries;
    }

    public Country getCountry(String code) {
        return countries.stream()
                .filter(country -> country.getCode().equalsIgnoreCase(code))
                .findFirst()
                .orElse(null);
    }

    public Country addCountry(Country country) {
        countries.add(country);
        return country;
    }

    public Country updateCountry(Country country) {
        for (int i = 0; i < countries.size(); i++) {
            if (countries.get(i).getCode().equalsIgnoreCase(country.getCode())) {
                countries.set(i, country);
                return country;
            }
        }
        return null;
    }

    public boolean deleteCountry(String code) {
        return countries.removeIf(country ->
                country.getCode().equalsIgnoreCase(code));
    }
}