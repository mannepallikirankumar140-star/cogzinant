package com.cognizant.spring_learn.dao;

import com.cognizant.spring_learn.exception.EmployeeNotFoundException;
import com.cognizant.spring_learn.model.Department;
import com.cognizant.spring_learn.model.Employee;
import com.cognizant.spring_learn.model.Skill;
import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Repository
public class EmployeeDao {

    private final List<Employee> employees = new ArrayList<>();

    public EmployeeDao() {
        try {
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

            employees.add(new Employee(
                    1,
                    "Dinesh",
                    50000.0,
                    true,
                    format.parse("15/05/2003"),
                    new Department(1, "Engineering"),
                    Arrays.asList(
                            new Skill(1, "Java"),
                            new Skill(2, "Spring Boot")
                    )
            ));

        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Employee> getAllEmployees() {
        return employees;
    }

    public Employee getEmployee(Integer id) {
        return employees.stream()
                .filter(employee -> employee.getId().equals(id))
                .findFirst()
                .orElseThrow(() ->
                        new EmployeeNotFoundException("Employee not found with id: " + id));
    }

    public Employee updateEmployee(Employee employee) {
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getId().equals(employee.getId())) {
                employees.set(i, employee);
                return employee;
            }
        }

        throw new EmployeeNotFoundException(
                "Employee not found with id: " + employee.getId()
        );
    }

    public void deleteEmployee(Integer id) {
        boolean removed = employees.removeIf(employee ->
                employee.getId().equals(id));

        if (!removed) {
            throw new EmployeeNotFoundException(
                    "Employee not found with id: " + id
            );
        }
    }
}