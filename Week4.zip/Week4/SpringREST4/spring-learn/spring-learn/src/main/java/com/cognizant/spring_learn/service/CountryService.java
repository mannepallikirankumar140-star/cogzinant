package com.cognizant.spring_learn.service;

import com.cognizant.spring_learn.dao.CountryDao;
import com.cognizant.spring_learn.model.Country;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CountryService {

    private final CountryDao countryDao;

    public CountryService(CountryDao countryDao) {
        this.countryDao = countryDao;
    }

    public List<Country> getAllCountries() {
        return countryDao.getAllCountries();
    }

    public Country getCountry(String code) {
        return countryDao.getCountry(code);
    }

    public Country addCountry(Country country) {
        return countryDao.addCountry(country);
    }

    public Country updateCountry(Country country) {
        return countryDao.updateCountry(country);
    }

    public boolean deleteCountry(String code) {
        return countryDao.deleteCountry(code);
    }
}