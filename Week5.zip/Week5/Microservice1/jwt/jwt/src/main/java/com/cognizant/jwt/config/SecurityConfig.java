package com.cognizant.jwt.config;

import com.cognizant.jwt.security.JwtTokenFilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.web.SecurityFilterChain;

import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    @Autowired
    JwtTokenFilter jwtTokenFilter;

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception{

        http

                .csrf(csrf->csrf.disable())

                .authorizeHttpRequests(auth->auth

                        .requestMatchers("/token").permitAll()

                        .anyRequest().authenticated())

                .addFilterBefore(jwtTokenFilter,
                        UsernamePasswordAuthenticationFilter.class);

        return http.build();

    }

}