package com.cognizant.jwt.controller;

import com.cognizant.jwt.security.JwtTokenProvider;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

@RestController
public class AuthController {

    @Autowired
    JwtTokenProvider provider;

    @GetMapping("/token")
    public String token(){

        return provider.createToken("Dinesh");

    }

}