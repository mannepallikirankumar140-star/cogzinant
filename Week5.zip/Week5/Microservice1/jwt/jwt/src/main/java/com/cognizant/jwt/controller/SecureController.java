package com.cognizant.jwt.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class SecureController {

    @GetMapping("/secure")

    public String secure(){

        return "JWT Authentication Successful";

    }

}